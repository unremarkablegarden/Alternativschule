var fromEvent = require('graphcool-lib').fromEvent;
var bcryptjs = require('bcryptjs');
var userQuery = "\nquery UserQuery($email: String!) {\n  User(email: $email){\n    id\n    password\n  }\n}";
var getGraphcoolUser = function (api, email) {
    return api.request(userQuery, { email: email })
        .then(function (userQueryResult) {
        if (userQueryResult.error) {
            return Promise.reject(userQueryResult.error);
        }
        else {
            return userQueryResult.User;
        }
    });
};
module.exports = function (event) {
    if (!event.context.graphcool.pat) {
        console.log('Please provide a valid root token!');
        return { error: 'Email Authentication not configured correctly.' };
    }
    // Retrieve payload from event
    var email = event.data.email;
    var password = event.data.password;
    // Create Graphcool API (based on https://github.com/graphcool/graphql-request)
    var graphcool = fromEvent(event);
    var api = graphcool.api('simple/v1');
    return getGraphcoolUser(api, email)
        .then(function (graphcoolUser) {
        if (!graphcoolUser) {
            return Promise.reject('Invalid Credentials'); //returning same generic error so user can't find out what emails are registered.
        }
        else {
            return bcryptjs.compare(password, graphcoolUser.password)
                .then(function (passwordCorrect) {
                if (passwordCorrect) {
                    return graphcoolUser.id;
                }
                else {
                    return Promise.reject('Invalid Credentials');
                }
            });
        }
    })
        .then(function (graphcoolUserId) {
        return graphcool.generateAuthToken(graphcoolUserId, 'User');
    })
        .then(function (token) {
        return { data: { token: token } };
    })
        .catch(function (error) {
        // Log error, but don't expose to caller
        console.log("Error: " + JSON.stringify(error));
        return { error: "An unexpected error occured" };
    });
};
