var fromEvent = require('graphcool-lib').fromEvent;
var bcryptjs = require('bcryptjs');
var validator = require('validator');
var userQuery = "\nquery UserQuery($email: String!) {\n  User(email: $email){\n    id\n    password\n  }\n}";
var createUserMutation = "\nmutation CreateUserMutation($email: String!, $passwordHash: String!) {\n  createUser(\n    email: $email,\n    password: $passwordHash\n  ) {\n    id\n  }\n}";
var getGraphcoolUser = function (api, email) {
    return api.request(userQuery, { email: email })
        .then(function (userQueryResult) {
        if (userQueryResult.error) {
            return Promise.reject(userQueryResult.error);
        }
        else {
            return userQueryResult.User;
        }
    });
};
var createGraphcoolUser = function (api, email, passwordHash) {
    return api.request(createUserMutation, { email: email, passwordHash: passwordHash })
        .then(function (userMutationResult) {
        return userMutationResult.createUser.id;
    });
};
module.exports = function (event) {
    if (!event.context.graphcool.pat) {
        console.log('Please provide a valid root token!');
        return { error: 'Email Signup not configured correctly.' };
    }
    // Retrieve payload from event
    var email = event.data.email;
    var password = event.data.password;
    // Create Graphcool API (based on https://github.com/graphcool/graphql-request)
    var graphcool = fromEvent(event);
    var api = graphcool.api('simple/v1');
    var SALT_ROUNDS = 10;
    var salt = bcryptjs.genSaltSync(SALT_ROUNDS);
    if (validator.isEmail(email)) {
        return getGraphcoolUser(api, email)
            .then(function (graphcoolUser) {
            if (!graphcoolUser) {
                return bcryptjs.hash(password, salt)
                    .then(function (hash) { return createGraphcoolUser(api, email, hash); });
            }
            else {
                return Promise.reject('Email already in use');
            }
        })
            .then(function (graphcoolUserId) {
            return graphcool.generateAuthToken(graphcoolUserId, 'User')
                .then(function (token) {
                return { data: { id: graphcoolUserId, token: token } };
            });
        })
            .catch(function (error) {
            // Log error, but don't expose to caller
            console.log("Error: " + JSON.stringify(error));
            return { error: 'An unexpected error occured.' };
        });
    }
    else {
        return { error: 'Not a valid email' };
    }
};
