var fromEvent = require('graphcool-lib').fromEvent;
var userQuery = "\nquery UserQuery($userId: ID!) {\n  User(id: $userId){\n    id\n    password\n  }\n}";
var getUser = function (api, userId) {
    return api.request(userQuery, { userId: userId })
        .then(function (userQueryResult) {
        return userQueryResult.User;
    })
        .catch(function (error) {
        // Log error, but don't expose to caller
        console.log("Error: " + JSON.stringify(error));
        return { error: "An unexpected error occured" };
    });
};
module.exports = function (event) {
    if (!event.context.auth || !event.context.auth.nodeId) {
        console.log("No auth context");
        return { data: { id: null } };
    }
    // Retrieve payload from event
    var userId = event.context.auth.nodeId;
    console.log("Node ID: " + userId);
    // Create Graphcool API (based on https://github.com/graphcool/graphql-request)  
    var graphcool = fromEvent(event);
    var api = graphcool.api('simple/v1');
    return getUser(api, userId)
        .then(function (emailUser) {
        if (!emailUser) {
            return { error: "No user with id: " + userId };
        }
        return { data: emailUser };
    })
        .catch(function (error) {
        // Log error, but don't expose to caller
        console.log("Error: " + JSON.stringify(error));
        return { error: "An unexpected error occured" };
    });
};
